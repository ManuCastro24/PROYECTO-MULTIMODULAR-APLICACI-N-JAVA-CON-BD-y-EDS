DROP DATABASE if exists Colegio;
CREATE SCHEMA IF NOT EXISTS Colegio DEFAULT CHARACTER SET utf8 ;
USE Colegio ;

-- -----------------------------------------------------
-- MiembroColegio
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS MiembroColegio (
  Nif VARCHAR(12) NOT NULL,
  Nombre VARCHAR(25) NOT NULL,
  Apellidos VARCHAR(45) NOT NULL,
  Telefono INT NOT NULL,
  FechaNac DATE NOT NULL,
  PRIMARY KEY (Nif, Nombre))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Alumno
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Alumno (
  idAlumno VARCHAR(12) NOT NULL UNIQUE,
  notaMedia DECIMAL(2) NOT NULL DEFAULT 0.0,
  PRIMARY KEY (idAlumno),
  FOREIGN KEY (idAlumno) REFERENCES MiembroColegio (Nif))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Profesor
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Profesor(
  idProfesor VARCHAR(12) NOT NULL UNIQUE,
  Especialidad VARCHAR(45) NOT NULL,
  PRIMARY KEY (idProfesor),
  FOREIGN KEY (idProfesor) REFERENCES MiembroColegio (Nif))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Asignatura
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Asignatura (
  idAsignatura INT NOT NULL AUTO_INCREMENT,
  Nombre VARCHAR(45) NOT NULL,
  NumHoras INT NULL DEFAULT 0,
  PRIMARY KEY (idAsignatura))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- CursoEscolar
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS CursoEscolar (
  idCurso INT NOT NULL AUTO_INCREMENT,
  NomCurso VARCHAR(45) NOT NULL,
  Capacidad INT NOT NULL DEFAULT 30,
  estadoCurso VARCHAR(15) NOT NULL DEFAULT 'Activo',
  AñoInicio INT NOT NULL,
  AñoFin INT NOT NULL,
  PRIMARY KEY (idCurso))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Imparte
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Imparte (
  NumAsignatura INT NOT NULL,
  CodProfesor VARCHAR(12) NOT NULL,
  INDEX idAsigntura (NumAsignatura ASC) VISIBLE,
  INDEX idProfesor (CodProfesor ASC) VISIBLE,
  PRIMARY KEY (CodProfesor, NumAsignatura),
  FOREIGN KEY (NumAsignatura) REFERENCES Asignatura (idAsignatura),
  FOREIGN KEY (CodProfesor) REFERENCES Profesor (idProfesor))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Matriculado
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Matriculados (
  CodAlumno VARCHAR(12) NOT NULL,
  CodAsignatura INT NOT NULL,
  CodCurso INT NOT NULL,
  PRIMARY KEY (CodAlumno, CodAsignatura, CodCurso),
  FOREIGN KEY (CodAlumno) REFERENCES Alumno (idAlumno),
  FOREIGN KEY (CodAsignatura) REFERENCES Asignatura (idAsignatura),
  FOREIGN KEY (CodCurso) REFERENCES CursoEscolar (idCurso))
ENGINE = InnoDB;

-- Insertar datos en la tabla MiembroColegio
INSERT INTO MiembroColegio (Nif, Nombre, Apellidos, Telefono, FechaNac) VALUES 
('52345678A', 'Juan', 'Pérez', 600123456, '2005-05-20'),
('73456789B', 'María', 'Gómez', 600234567, '2006-08-15'),
('84567890D', 'Luis', 'Martínez', 600345678, '2012-11-30'),
('95678901F', 'Ana', 'López', 600456789, '1980-02-25'),
('12345678G', 'Carlos', 'Hernández', 600567890, '1995-12-10'),
('23456789H', 'Lucía', 'Ramírez', 600678901, '1998-03-15'),
('34567890J', 'Jorge', 'Sánchez', 600789012, '2002-07-19'),
('45678901K', 'Elena', 'Torres', 600890123, '1985-11-05'),
('56789012L', 'Roberto', 'Castro', 600901234, '2000-01-25');

-- Insertar datos en la tabla Alumno, usando Nif de MiembroColegio existente
INSERT INTO Alumno (idAlumno, notaMedia) VALUES 
('52345678A', 5.5),
('73456789B', 6.0),
('12345678G', 7.2),
('23456789H', 8.4),
('34567890J', 9.1),
('56789012L', 4.5);

-- Insertar datos en la tabla Profesor, usando Nif de MiembroColegio existente
INSERT INTO Profesor (idProfesor, Especialidad) VALUES 
('84567890D', 'Matemáticas'),
('95678901F', 'Lengua'),
('45678901K', 'Historia'),
('56789012L', 'Ciencias'),
('12345678G', 'Educación Física');

-- Insertar datos en la tabla Asignatura
INSERT INTO Asignatura (Nombre, NumHoras) VALUES 
('Matemáticas', 100),
('Lengua Española', 120),
('Inglés', 150),
('Historia', 90),
('Ciencias Naturales', 110),
('Educación Física', 80);

-- Insertar datos en la tabla CursoEscolar
INSERT INTO CursoEscolar (NomCurso, Capacidad, estadoCurso, AñoInicio, AñoFin) VALUES 
('Primero de ESO', 30, 'Activo', 2023, 2024),
('Segundo de ESO', 30, 'Activo', 2023, 2024),
('Tercero de ESO', 25, 'Activo', 2023, 2024),
('Cuarto de ESO', 25, 'Activo', 2023, 2024),
('Primero de Bachillerato', 20, 'Activo', 2023, 2024),
('Segundo de Bachillerato', 20, 'Activo', 2023, 2024);

-- Insertar datos en la tabla Imparte
INSERT INTO Imparte (NumAsignatura, CodProfesor) VALUES 
(1, '84567890D'), 
(2, '95678901F'),
(3, '95678901F'),
(4, '45678901K'),
(5, '56789012L'),
(6, '12345678G');

-- Insertar datos en la tabla Matriculado
INSERT INTO Matriculados (CodAlumno, CodAsignatura, CodCurso) VALUES 
('52345678A', 1, 1), 
('52345678A', 2, 1), 
('73456789B', 1, 2),  
('73456789B', 2, 2),
('12345678G', 3, 3),
('12345678G', 4, 3),
('23456789H', 5, 4),
('23456789H', 6, 4),
('34567890J', 1, 5),
('34567890J', 2, 5);

SET SQL_SAFE_UPDATES = 0;

-- Obtener el nombre y la especialidad de los profesores que enseñan más de una asignatura
SELECT Profesor.idProfesor, MiembroColegio.Nombre AS NombreProfesor, Profesor.Especialidad, COUNT(Imparte.NumAsignatura) AS NumAsignaturas
FROM Profesor
JOIN MiembroColegio ON Profesor.idProfesor = MiembroColegio.Nif
JOIN Imparte ON Profesor.idProfesor = Imparte.CodProfesor
GROUP BY Profesor.idProfesor, MiembroColegio.Nombre, Profesor.Especialidad
HAVING COUNT(Imparte.NumAsignatura) > 1;

-- Obtener los nombres de los alumnos junto con las asignaturas en las que están matriculados y el nombre del curso
SELECT MiembroColegio.Nombre AS NombreAlumno, Asignatura.Nombre AS Asignatura, CursoEscolar.NomCurso AS Curso
FROM Alumno
JOIN Matriculados ON Alumno.idAlumno = Matriculados.CodAlumno
JOIN Asignatura ON Matriculados.CodAsignatura = Asignatura.idAsignatura
JOIN CursoEscolar ON Matriculados.CodCurso = CursoEscolar.idCurso
JOIN MiembroColegio ON Alumno.idAlumno = MiembroColegio.Nif;

-- Obtener el nombre y la nota media del alumno con la nota más alta
SELECT MiembroColegio.Nombre AS NombreAlumno, Alumno.notaMedia
FROM Alumno
JOIN MiembroColegio ON Alumno.idAlumno = MiembroColegio.Nif
WHERE Alumno.notaMedia = (SELECT MAX(notaMedia) FROM Alumno);

-- Obtener la cantidad de alumnos matriculados en cada curso
SELECT CursoEscolar.NomCurso, COUNT(Matriculados.CodAlumno) AS NumAlumnos
FROM CursoEscolar
JOIN Matriculados ON CursoEscolar.idCurso = Matriculados.CodCurso
JOIN Alumno ON Matriculados.CodAlumno = Alumno.idAlumno
JOIN MiembroColegio ON Alumno.idAlumno = MiembroColegio.Nif
GROUP BY CursoEscolar.NomCurso;

-- Obtener la nota media de los alumnos agrupados por curso
SELECT CursoEscolar.NomCurso, AVG(Alumno.notaMedia) AS NotaMedia
FROM CursoEscolar
JOIN Matriculados ON CursoEscolar.idCurso = Matriculados.CodCurso
JOIN Alumno ON Matriculados.CodAlumno = Alumno.idAlumno
JOIN MiembroColegio ON Alumno.idAlumno = MiembroColegio.Nif
GROUP BY CursoEscolar.NomCurso;

-- Obtener los profesores que tienen más de 20 años de edad
SELECT Profesor.idProfesor, MiembroColegio.Nombre, MiembroColegio.Apellidos, MiembroColegio.FechaNac
FROM Profesor
JOIN MiembroColegio ON Profesor.idProfesor = MiembroColegio.Nif
WHERE YEAR(CURDATE()) - YEAR(MiembroColegio.FechaNac) > 20;

-- Obtener los nombres de los alumnos que están matriculados en un curso específico y cuya nota media es superior a un valor dado (por ejemplo, 6.0)
SELECT MiembroColegio.Nombre AS NombreAlumno, Alumno.notaMedia, CursoEscolar.NomCurso
FROM Alumno
JOIN MiembroColegio ON Alumno.idAlumno = MiembroColegio.Nif
JOIN Matriculados ON Alumno.idAlumno = Matriculados.CodAlumno
JOIN CursoEscolar ON Matriculados.CodCurso = CursoEscolar.idCurso
WHERE CursoEscolar.NomCurso = 'Primero de ESO' AND Alumno.notaMedia > 6.0;

-- Actualizar el estado del curso a 'Finalizado' para los cursos que terminaron antes del año actual
UPDATE CursoEscolar
SET estadoCurso = 'Finalizado'
WHERE AñoFin < YEAR(CURDATE());

-- Incrementar la nota media de todos los alumnos en 0.5 puntos que están matriculados en 'Matemáticas' sin exceder 10
UPDATE Alumno
SET notaMedia = CASE WHEN notaMedia < 9.5 THEN notaMedia + 0.5
                     ELSE 10 END
WHERE idAlumno IN (
    SELECT CodAlumno
    FROM Matriculados
    WHERE CodAsignatura = (
        SELECT idAsignatura
        FROM Asignatura
        WHERE Nombre = 'Matemáticas'
    )
);

-- Eliminar alumnos que no estén matriculados en ningún curso
DELETE FROM Alumno
WHERE idAlumno NOT IN (
    SELECT CodAlumno
    FROM Matriculados
);

-- Vista de Alumnos y sus Cursos
DROP VIEW IF EXISTS VistaAlumnosCursos;
CREATE VIEW VistaAlumnosCursos AS
SELECT MiembroColegio.Nombre AS NombreAlumno, Asignatura.Nombre AS Asignatura, CursoEscolar.NomCurso AS Curso
FROM Alumno
JOIN Matriculados ON Alumno.idAlumno = Matriculados.CodAlumno
JOIN Asignatura ON Matriculados.CodAsignatura = Asignatura.idAsignatura
JOIN CursoEscolar ON Matriculados.CodCurso = CursoEscolar.idCurso
JOIN MiembroColegio ON Alumno.idAlumno = MiembroColegio.Nif;

SELECT * FROM VistaAlumnosCursos;

-- Vista de Profesores y sus Asignaturas
DROP VIEW IF EXISTS VistaProfesoresAsignaturas;
CREATE VIEW VistaProfesoresAsignaturas AS
SELECT Profesor.idProfesor, MiembroColegio.Nombre AS NombreProfesor, Asignatura.Nombre AS Asignatura
FROM Profesor
JOIN MiembroColegio ON Profesor.idProfesor = MiembroColegio.Nif
JOIN Imparte ON Profesor.idProfesor = Imparte.CodProfesor
JOIN Asignatura ON Imparte.NumAsignatura = Asignatura.idAsignatura;

SELECT * FROM VistaProfesoresAsignaturas;

-- Procedimiento para Obtener la Nota Media de un Curso
DROP PROCEDURE IF EXISTS ObtenerNotaMediaCurso;
DELIMITER $$
CREATE PROCEDURE ObtenerNotaMediaCurso(IN cursoID INT)
BEGIN
    SELECT AVG(Alumno.notaMedia) AS NotaMedia
    FROM Alumno
    JOIN Matriculados ON Alumno.idAlumno = Matriculados.CodAlumno
    WHERE Matriculados.CodCurso = cursoID;
END $$
DELIMITER ;

CALL ObtenerNotaMediaCurso(1);

-- Procedimiento para Asignar Nota a un Alumno
DROP PROCEDURE IF EXISTS AsignarNotaAlumno;
DELIMITER $$
CREATE PROCEDURE AsignarNotaAlumno(IN alumnoID VARCHAR(12), IN nuevaNota DECIMAL(3, 2))
BEGIN
    UPDATE Alumno
    SET notaMedia = nuevaNota
    WHERE idAlumno = alumnoID;
END $$
DELIMITER ;

CALL AsignarNotaAlumno('52345678A', 3.0);

-- Disparador BEFORE INSERT para ajustar notaMedia
DELIMITER $$
CREATE TRIGGER InsertarNotaMedia
BEFORE INSERT ON Alumno
FOR EACH ROW
BEGIN
    IF NEW.notaMedia < 0 THEN
        SET NEW.notaMedia = 0;
    ELSEIF NEW.notaMedia > 10 THEN
        SET NEW.notaMedia = 10;
    END IF;
END;
$$
DELIMITER ;

-- Disparador AFTER INSERT para verificar capacidad del curso
DELIMITER $$
CREATE TRIGGER InsertarAlumnos
AFTER INSERT ON Matriculados
FOR EACH ROW
BEGIN
    DECLARE capacidad INT;
    DECLARE numMatriculados INT;

    -- Obtener la capacidad del curso
    SELECT Capacidad INTO capacidad
    FROM CursoEscolar
    WHERE idCurso = NEW.CodCurso;

    -- Contar el número de alumnos matriculados en el curso
    SELECT COUNT(*) INTO numMatriculados
    FROM Matriculados
    WHERE CodCurso = NEW.CodCurso;

    -- Verificar si la capacidad del curso se ha excedido
    IF numMatriculados > capacidad THEN
        -- Eliminar la matrícula recién insertada
        DELETE FROM Matriculados
        WHERE CodAlumno = NEW.CodAlumno
          AND CodAsignatura = NEW.CodAsignatura
          AND CodCurso = NEW.CodCurso;
        
        -- Lanzar un error
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Capacidad del curso excedida.';
    END IF;
END;
$$
DELIMITER ;

-- Probar el disparador InsertarNotaMedia:
-- Insertar un alumno con una nota media fuera del rango permitido
INSERT INTO MiembroColegio (Nif, Nombre, Apellidos, Telefono, FechaNac) VALUES
('99999999Z', 'Prueba', 'Alumno', 600123456, '2000-01-01');
INSERT INTO MiembroColegio (Nif, Nombre, Apellidos, Telefono, FechaNac) VALUES
('88888888Y', 'Prueba1', 'Alumno1', 604123456, '2006-02-01');

INSERT INTO Alumno (idAlumno, notaMedia) VALUES ('99999999Z', -5);  -- Se ajustará a 0
INSERT INTO Alumno (idAlumno, notaMedia) VALUES ('88888888Y', 12);  -- Se ajustará a 10

-- Verificar las inserciones
SELECT * FROM Alumno;

-- Probar el disparador InsertarAlumnos:
-- Insertar datos en las tablas necesarias para probar el disparador

-- Crear un curso con capacidad de 2 alumnos
INSERT INTO CursoEscolar (idCurso, NomCurso, Capacidad, estadoCurso, AñoInicio, AñoFin) VALUES 
(10, 'Curso de Prueba', 2, 'Activo', 2023, 2024);

-- Crear alumnos
INSERT INTO MiembroColegio (Nif, Nombre, Apellidos, Telefono, FechaNac) VALUES 
('11111111A', 'Alumno', 'Uno', 600000001, '2000-01-01'),
('22222222B', 'Alumno', 'Dos', 600000002, '2000-01-02'),
('33333333C', 'Alumno', 'Tres', 600000003, '2000-01-03');

INSERT INTO Alumno (idAlumno, notaMedia) VALUES 
('11111111A', 6.0),
('22222222B', 7.5),
('33333333C', 8.5);

-- Crear asignatura
INSERT INTO Asignatura (idAsignatura, Nombre, NumHoras) VALUES 
(15, 'Asignatura de Prueba', 50);

-- Matricular alumnos en el curso hasta alcanzar la capacidad
INSERT INTO Matriculados (CodAlumno, CodAsignatura, CodCurso) VALUES 
('11111111A', 15, 10),
('22222222B', 15, 10);

-- Intentar matricular un tercer alumno en el mismo curso, lo que debería activar el disparador
INSERT INTO Matriculados (CodAlumno, CodAsignatura, CodCurso) VALUES 
('33333333C', 15, 10);

SET SQL_SAFE_UPDATES = 1;

SELECT * FROM Alumno;
SELECT * from CursoEscolar;
Select * from Profesor;

SELECT * FROM Alumno WHERE idAlumno='29546896S';
/*
SET FOREIGN_KEY_CHECKS = 0;


TRUNCATE TABLE Matriculado;
TRUNCATE TABLE Imparte;
TRUNCATE TABLE CursoEscolar;
TRUNCATE TABLE Asignatura;
TRUNCATE TABLE Profesor;
TRUNCATE TABLE Alumno;
TRUNCATE TABLE MiembroColegio;

SET FOREIGN_KEY_CHECKS = 1;
*/